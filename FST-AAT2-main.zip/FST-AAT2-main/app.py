import logging
import os
import uuid
from datetime import datetime, timezone

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from flask import Flask, flash, redirect, render_template, request, session, url_for
from pymongo import MongoClient, ReturnDocument
from pymongo.errors import DuplicateKeyError, PyMongoError
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY") or os.urandom(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)
logger = logging.getLogger(__name__)

csv_df = pd.read_csv(os.path.join(app.root_path, "tourism_destinations.csv"))
PAYMENT_METHODS = ("UPI (demo)", "Card (demo)", "Net banking (demo)", "Pay on arrival")


def mongo_client():
    return MongoClient(
        os.getenv("MONGODB_URI", "mongodb://127.0.0.1:27017"),
        serverSelectionTimeoutMS=3000,
    )


def record_activity(database, action, details=None):
    database.activity.insert_one({
        "user_id": session.get("user_id"),
        "action": action,
        "details": details or {},
        "created_at": datetime.now(timezone.utc),
    })


def load_destinations():
    try:
        with mongo_client() as client:
            collection = client[
                os.getenv("MONGODB_DATABASE", "smart_tourism")
            ][os.getenv("MONGODB_COLLECTION", "destinations")]
            collection.find_one({})

            if collection.count_documents({}) == 0:
                records = csv_df.fillna("").to_dict("records")
                if records:
                    collection.insert_many(records)

            records = list(collection.find({}, {"_id": 0}))
        return pd.DataFrame(records)
    except PyMongoError as error:
        logger.warning("MongoDB unavailable; using CSV data: %s", error)
        return csv_df.copy()


def require_login():
    if not session.get("user_id"):
        flash("Please log in to continue.", "error")
        return redirect(url_for("account"))
    return None


@app.context_processor
def inject_user():
    if session.get("user_id"):
        return {"current_user": {
            "name": session.get("user_name", ""),
            "email": session.get("user_email", ""),
        }}
    return {"current_user": None}


@app.route("/", methods=["GET", "POST"])
def home():
    recommendations = []
    budget = 0
    days = 1
    category = "All"
    error = ""

    if request.method == "POST":
        try:
            with mongo_client() as client:
                database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
                record_activity(database, "search_requested", {
                    "submitted_budget": request.form.get("budget", "")[:32],
                    "submitted_days": request.form.get("days", "")[:3],
                    "category": request.form.get("category", "All")[:40],
                })
        except PyMongoError:
            logger.exception("Could not save search activity")
            error = "Could not save your search to MongoDB. Check that MongoDB is running and try again."
        try:
            if error:
                raise RuntimeError("Search activity was not saved.")
            budget = float(request.form.get("budget", ""))
            days = int(request.form.get("days", ""))
            category = request.form.get("category", "All")

            if budget <= 0:
                error = "Please enter a budget greater than zero."
            elif days < 1 or days > 30:
                error = "Please enter travel duration between 1 and 30 days."
            else:
                daily_budget = budget / days
                destination_df = load_destinations()
                filtered = destination_df[
                    destination_df["Estimated_Daily_Budget_INR"] <= daily_budget
                ]
                if category != "All":
                    filtered = filtered[filtered["Category"] == category]

                recommendations = filtered.to_dict("records")
                for place in recommendations:
                    attractions = [
                        attraction.strip()
                        for attraction in str(place["Attractions"]).split(";")
                        if attraction.strip()
                    ] or ["Explore the destination"]
                    place["itinerary"] = [
                        {
                            "day": day + 1,
                            "places": [
                                attractions[(day * 2) % len(attractions)],
                                attractions[(day * 2 + 1) % len(attractions)],
                            ],
                        }
                        for day in range(days)
                    ]
                    place["total_cost"] = (
                        float(place["Estimated_Daily_Budget_INR"]) * days
                    )
                    place["accommodation"] = round(place["total_cost"] * 0.40)
                    place["food"] = round(place["total_cost"] * 0.30)
                    place["transport"] = round(place["total_cost"] * 0.30)

                if not filtered.empty:
                    plt.figure(figsize=(9, 4))
                    plt.bar(
                        filtered["Destination"],
                        filtered["Estimated_Daily_Budget_INR"],
                    )
                    plt.title("Recommended Destination Budget")
                    plt.xlabel("Destination")
                    plt.ylabel("Estimated Daily Budget (INR)")
                    plt.xticks(rotation=30)
                    plt.tight_layout()
                    plt.savefig(os.path.join(app.root_path, "static", "budget_chart.png"))
                    plt.close()
        except RuntimeError:
            pass
        except ValueError:
            error = "Please enter valid numbers for budget and travel duration."
        except PyMongoError:
            logger.exception("Could not save search activity")
            error = "Could not save your search to MongoDB. Check that MongoDB is running and try again."

    return render_template(
        "index.html",
        recommendations=recommendations,
        budget=budget,
        days=days,
        category=category,
        error=error,
    )


@app.route("/account", methods=["GET"])
def account():
    if session.get("user_id"):
        return redirect(url_for("bookings"))
    return render_template("account.html")


@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name", "").strip()[:100]
    email = request.form.get("email", "").strip().lower()[:254]
    password = request.form.get("password", "")
    if not name or "@" not in email or len(password) < 8:
        flash("Enter your name, a valid email, and a password of at least 8 characters.", "error")
        return redirect(url_for("account"))

    user_id = str(uuid.uuid4())
    try:
        with mongo_client() as client:
            database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
            database.users.create_index("email", unique=True)
            database.users.insert_one({
                "_id": user_id,
                "name": name,
                "email": email,
                "password_hash": generate_password_hash(password),
                "created_at": datetime.now(timezone.utc),
            })
            session["user_id"] = user_id
            session["user_name"] = name
            session["user_email"] = email
            record_activity(database, "register", {"email": email})
    except DuplicateKeyError:
        flash("An account with that email already exists. Please log in.", "error")
        return redirect(url_for("account"))
    except PyMongoError:
        logger.exception("Could not register account")
        flash("Could not save your account to MongoDB. Check that MongoDB is running and try again.", "error")
        return redirect(url_for("account"))

    flash("Account created. You are now logged in.", "success")
    return redirect(url_for("bookings"))


@app.route("/login", methods=["POST"])
def login():
    email = request.form.get("email", "").strip().lower()[:254]
    password = request.form.get("password", "")
    try:
        with mongo_client() as client:
            database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
            user = database.users.find_one({"email": email})
            if not user or not check_password_hash(user["password_hash"], password):
                record_activity(database, "login_failed", {"email": email})
                flash("Email or password is incorrect.", "error")
                return redirect(url_for("account"))
            session.clear()
            session["user_id"] = user["_id"]
            session["user_name"] = user["name"]
            session["user_email"] = user["email"]
            record_activity(database, "login", {"email": email})
    except PyMongoError:
        logger.exception("Could not log in")
        flash("Could not connect to MongoDB. Check that MongoDB is running and try again.", "error")
        return redirect(url_for("account"))

    flash("Welcome back.", "success")
    return redirect(url_for("bookings"))


@app.route("/logout", methods=["POST"])
def logout():
    if session.get("user_id"):
        try:
            with mongo_client() as client:
                database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
                record_activity(database, "logout")
        except PyMongoError:
            logger.exception("Could not record logout activity")
            flash("Could not record your logout. Please try again.", "error")
            return redirect(url_for("bookings"))
    session.clear()
    flash("You are logged out.", "success")
    return redirect(url_for("home"))


@app.route("/book/<destination>", methods=["POST"])
def book_destination(destination):
    login_redirect = require_login()
    if login_redirect:
        return login_redirect
    try:
        days = int(request.form.get("days", "1"))
        if days < 1 or days > 30:
            raise ValueError
        destinations = load_destinations()
        matches = destinations[destinations["Destination"] == destination]
        if matches.empty:
            flash("That destination could not be found.", "error")
            return redirect(url_for("home"))
        place = matches.iloc[0]
        daily_rate = float(place["Estimated_Daily_Budget_INR"])
        amount = round(daily_rate * days, 2)
        booking_id = str(uuid.uuid4())
        with mongo_client() as client:
            database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
            database.bookings.insert_one({
                "_id": booking_id,
                "user_id": session["user_id"],
                "destination": destination,
                "days": days,
                "daily_rate": daily_rate,
                "amount": amount,
                "status": "awaiting_demo_payment",
                "created_at": datetime.now(timezone.utc),
            })
            record_activity(database, "booking_created", {
                "booking_id": booking_id,
                "destination": destination,
                "days": days,
                "amount": amount,
            })
    except (ValueError, TypeError):
        flash("Choose a travel duration between 1 and 30 days.", "error")
        return redirect(url_for("home"))
    except PyMongoError:
        logger.exception("Could not save booking")
        flash("Could not save your booking to MongoDB. Please try again.", "error")
        return redirect(url_for("home"))
    return redirect(url_for("checkout", booking_id=booking_id))


@app.route("/booking/<booking_id>", methods=["GET"])
def checkout(booking_id):
    login_redirect = require_login()
    if login_redirect:
        return login_redirect
    try:
        with mongo_client() as client:
            database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
            booking = database.bookings.find_one({
                "_id": booking_id,
                "user_id": session["user_id"],
            })
            if booking:
                record_activity(database, "checkout_viewed", {
                    "booking_id": booking_id,
                    "destination": booking["destination"],
                    "amount": booking["amount"],
                })
    except PyMongoError:
        logger.exception("Could not load booking")
        flash("Could not load your booking from MongoDB.", "error")
        return redirect(url_for("bookings"))
    if not booking:
        flash("Booking not found.", "error")
        return redirect(url_for("bookings"))
    return render_template("checkout.html", booking=booking, payment_methods=PAYMENT_METHODS)


@app.route("/booking/<booking_id>/pay", methods=["POST"])
def record_demo_payment(booking_id):
    login_redirect = require_login()
    if login_redirect:
        return login_redirect
    method = request.form.get("payment_method", "")
    if method not in PAYMENT_METHODS:
        flash("Choose one of the listed demo payment methods.", "error")
        return redirect(url_for("checkout", booking_id=booking_id))
    try:
        with mongo_client() as client:
            database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
            booking = database.bookings.find_one_and_update(
                {
                    "_id": booking_id,
                    "user_id": session["user_id"],
                    "status": "awaiting_demo_payment",
                },
                {"$set": {
                    "status": "demo_payment_recorded",
                    "payment_method": method,
                    "paid_at": datetime.now(timezone.utc),
                }},
                return_document=ReturnDocument.AFTER,
            )
            if not booking:
                flash("Booking not found or payment was already recorded.", "error")
                return redirect(url_for("bookings"))
            record_activity(database, "demo_payment_recorded", {
                "booking_id": booking_id,
                "destination": booking["destination"],
                "amount": booking["amount"],
                "payment_method": method,
                "charged": False,
            })
    except PyMongoError:
        logger.exception("Could not record demo payment")
        flash("Could not record your payment selection to MongoDB. Please try again.", "error")
        return redirect(url_for("checkout", booking_id=booking_id))
    flash("Demo payment recorded. No money was charged.", "success")
    return redirect(url_for("bookings"))


@app.route("/bookings", methods=["GET"])
def bookings():
    login_redirect = require_login()
    if login_redirect:
        return login_redirect
    try:
        with mongo_client() as client:
            database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
            record_activity(database, "bookings_viewed")
            records = list(database.bookings.find(
                {"user_id": session["user_id"]}
            ).sort("created_at", -1))
    except PyMongoError:
        logger.exception("Could not load bookings")
        flash("Could not load your bookings from MongoDB.", "error")
        records = []
    return render_template("bookings.html", bookings=records)


@app.route("/feedback", methods=["GET", "POST"])
def feedback():
    login_redirect = require_login()
    if login_redirect:
        return login_redirect
    destinations = sorted(csv_df["Destination"].dropna().unique().tolist())
    if request.method == "POST":
        try:
            rating = int(request.form.get("rating", ""))
            message = request.form.get("message", "").strip()[:2000]
            destination = request.form.get("destination", "")
            if rating < 1 or rating > 5 or not message:
                raise ValueError
            if destination and destination not in destinations:
                raise ValueError
        except ValueError:
            flash("Select a rating from 1 to 5 and enter feedback.", "error")
            return redirect(url_for("feedback"))
        try:
            with mongo_client() as client:
                database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
                if request.method == "GET":
                    record_activity(database, "feedback_page_viewed")
                feedback_id = str(uuid.uuid4())
                database.feedback.insert_one({
                    "_id": feedback_id,
                    "user_id": session["user_id"],
                    "rating": rating,
                    "message": message,
                    "destination": destination or None,
                    "created_at": datetime.now(timezone.utc),
                })
                record_activity(database, "feedback_submitted", {
                    "feedback_id": feedback_id,
                    "rating": rating,
                    "destination": destination or None,
                })
        except PyMongoError:
            logger.exception("Could not save feedback")
            flash("Could not save your feedback to MongoDB. Please try again.", "error")
            return redirect(url_for("feedback"))
        flash("Thanks for sharing your feedback.", "success")
        return redirect(url_for("feedback"))
    try:
        with mongo_client() as client:
            entries = list(client[
                os.getenv("MONGODB_DATABASE", "smart_tourism")
            ].feedback.find({"user_id": session["user_id"]}).sort("created_at", -1))
    except PyMongoError:
        logger.exception("Could not load feedback")
        flash("Could not load your feedback from MongoDB.", "error")
        entries = []
    return render_template("feedback.html", destinations=destinations, feedback_entries=entries)


@app.route("/activity", methods=["GET"])
def activity():
    login_redirect = require_login()
    if login_redirect:
        return login_redirect
    try:
        with mongo_client() as client:
            database = client[os.getenv("MONGODB_DATABASE", "smart_tourism")]
            record_activity(database, "activity_viewed")
            entries = list(database.activity.find(
                {"user_id": session["user_id"]}
            ).sort("created_at", -1).limit(100))
    except PyMongoError:
        logger.exception("Could not load activity")
        flash("Could not load your activity from MongoDB.", "error")
        entries = []
    return render_template("activity.html", activities=entries)


if __name__ == "__main__":
    app.run(debug=True)
